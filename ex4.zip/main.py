from my_model import *
print(a*b - c)
from my_model_1 import a 
from my_model_2 import  a
print(a)

import my_model_1
import my_model_2
print(my_model_1.a * my_model_2.a)
import my_model as mm
print(mm.a)
print(mm.a/(1-mm.a**3))
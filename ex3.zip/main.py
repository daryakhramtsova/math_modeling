from my_model import a #инструкция копирующая атребуты модуля
print(a)
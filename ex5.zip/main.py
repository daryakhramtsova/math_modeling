
from my_model import gravity_constant as G
g=500*G/10*2

print(g)